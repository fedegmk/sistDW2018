Pasos para correr la solución
----------------------------------------------------------------------
----------------------------------------------------------------------

1. Crear, en GeoKettle, una conexión a un server PostgreSQL 10
   (con extensión de postgis en el esquema públic, se logra crear 
   una ejecutando la siguiente sentencia: CREATE EXTENSION postgis;)

   Recomendamos que la conexión tenga los siguientes parámetros:

   Nombre: localhost_dw
   Servidor: localhost
   Base: datawarehouse
   Puerto: 5432
   Usuario: postgres
   Pass: postgres

2. Exportar los reportes a través del report designer al Pentaho BI 
   Server.

3. Subir, a través del browser de Pentaho BI, los archivos del
   dashboard. 

La solución también funciona con la versión 9.6 de PostgreSQL. 
